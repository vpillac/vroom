
package umontreal.iro.lecuyer.charts;

import   org.jfree.data.xy.XYSeries;
import   org.jfree.data.xy.XYSeriesCollection;
import   org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;


/**
 * This class extends 
 * {@link umontreal.iro.lecuyer.charts.XYListSeriesCollection XYListSeriesCollection}.
 * The data is given as lists of <SPAN CLASS="MATH"><I>y</I></SPAN>-coordinates. The <SPAN CLASS="MATH"><I>x</I></SPAN>-coordinates are
 * simply the indices + 1 of each <SPAN CLASS="MATH"><I>y</I></SPAN>-coordinate in the given lists.
 * 
 */
public class YListSeriesCollection extends XYListSeriesCollection  {



   /**
    * Creates a new <TT>YListSeriesCollection</TT> instance with default
    *    parameters and given data series.
    *    The input vectors represent sets of plotting data.
    *    More specifically, each vector <TT>data</TT> represents a <SPAN CLASS="MATH"><I>y</I></SPAN>-coordinates set.
    *    Position in the vector will form the <SPAN CLASS="MATH"><I>x</I></SPAN>-coordinates. Indeed the value
    *    <TT>data</TT><SPAN CLASS="MATH">[<I>j</I>]</SPAN> corresponds to the point 
    *    
    * <SPAN CLASS="MATH">(<I>j</I> + 1,<TT>data</TT>[<I>j</I>])</SPAN> on the chart.
    * 
    * @param data series of point sets.
    * 
    * 
    */
   public YListSeriesCollection (double[]... data)  {
      renderer = new XYLineAndShapeRenderer();
      ((XYLineAndShapeRenderer)renderer).setShapesVisible(false);
      seriesCollection = new XYSeriesCollection();

      XYSeriesCollection tempSeriesCollection =
          (XYSeriesCollection)seriesCollection;
      for (int i = 0; i < data.length; i ++) {
         XYSeries serie = new XYSeries(" ");
         for (int j = 0; j < data[i].length; j++)
            serie.add(j+1, data[i][j]);
         tempSeriesCollection.addSeries(serie);
      }

      // set default colors
      for(int i = 0; i < tempSeriesCollection.getSeriesCount(); i++) {
         renderer.setSeriesPaint(i, getDefaultColor(i));
      }

      // set default plot style
      plotStyle = new String[tempSeriesCollection.getSeriesCount()];
      marksType = new String[tempSeriesCollection.getSeriesCount()];
      dashPattern = new String[tempSeriesCollection.getSeriesCount()];
      for (int i = 0; i < tempSeriesCollection.getSeriesCount(); i++) {
         marksType[i] = " ";
         plotStyle[i] = "smooth";
         dashPattern[i] = "solid";
      }
   }


   /**
    * Creates a new <TT>YListSeriesCollection</TT> instance with default
    *    parameters and one data series.
    *    The vector <TT>data</TT> represents a set of plotting data.
    *    Position in the vector represents the <SPAN CLASS="MATH"><I>x</I></SPAN>-coordinate of the points:
    *     thus the coordinates of the points are given by
    *    
    * <SPAN CLASS="MATH">(<I>j</I> + 1,<TT>data</TT>[<I>j</I>])</SPAN>.
    *   However, only <SPAN  CLASS="textit">the first</SPAN> <TT>numPoints</TT> of <TT>data</TT> will
    *   be considered in the series.
    * 
    * @param data point set.
    * 
    *    @param numPoints Number of points to plot
    * 
    * 
    */
   public YListSeriesCollection (double[] data, int numPoints)  {
      renderer = new XYLineAndShapeRenderer();
      ((XYLineAndShapeRenderer)renderer).setShapesVisible(false);
      seriesCollection = new XYSeriesCollection();

      XYSeriesCollection tempSeriesCollection =
          (XYSeriesCollection)seriesCollection;
      XYSeries serie = new XYSeries(" ");
      for (int j = 0; j < numPoints; j++)
         serie.add(j+1, data[j]);
      tempSeriesCollection.addSeries(serie);

      // set default colors
      renderer.setSeriesPaint(0, getDefaultColor(0));

      // set default plot style
      plotStyle = new String[1];
      marksType = new String[1];
      dashPattern = new String[1];
      marksType[0] = " ";
      plotStyle[0] = "smooth";
      dashPattern[0] = "solid";
   }


   /**
    * Creates a new <TT>YListSeriesCollection</TT> instance with default
    *    parameters and given data series.
    *    The matrix <TT>data</TT> represents a set of plotting data.
    *    More specifically, each row of <TT>data</TT> represents a <SPAN CLASS="MATH"><I>y</I></SPAN>-coordinates set.
    *    Position in the vector will form the <SPAN CLASS="MATH"><I>x</I></SPAN>-coordinates. Indeed, for each serie
    *    <SPAN CLASS="MATH"><I>i</I></SPAN>, the value <TT>data</TT><SPAN CLASS="MATH">[<I>i</I>][<I>j</I>]</SPAN> corresponds to the point 
    *    
    * <SPAN CLASS="MATH">(<I>j</I> + 1,<TT>data</TT>[<I>j</I>])</SPAN> on the chart.
    *   However, only <SPAN  CLASS="textit">the first</SPAN> <TT>numPoints</TT> of <TT>data</TT> will
    *   be considered for each series of points.
    * 
    * @param data series of point sets.
    * 
    *    @param numPoints Number of points to plot
    * 
    */
   public YListSeriesCollection (double[][] data, int numPoints)  {
      renderer = new XYLineAndShapeRenderer();
      ((XYLineAndShapeRenderer)renderer).setShapesVisible(false);
      seriesCollection = new XYSeriesCollection();

      XYSeriesCollection tempSeriesCollection =
          (XYSeriesCollection)seriesCollection;
      for (int i = 0; i < data.length; i ++) {
         XYSeries serie = new XYSeries(" ");
         for (int j = 0; j < numPoints; j++)
            serie.add(j+1, data[i][j]);
         tempSeriesCollection.addSeries(serie);
      }

      // set default colors
      for(int i = 0; i < tempSeriesCollection.getSeriesCount(); i++) {
         renderer.setSeriesPaint(i, getDefaultColor(i));
      }

      // set default plot style
      plotStyle = new String[tempSeriesCollection.getSeriesCount()];
      marksType = new String[tempSeriesCollection.getSeriesCount()];
      dashPattern = new String[tempSeriesCollection.getSeriesCount()];
      for (int i = 0; i < tempSeriesCollection.getSeriesCount(); i++) {
         marksType[i] = " ";
         plotStyle[i] = "smooth";
         dashPattern[i] = "solid";
      }
   }
}
