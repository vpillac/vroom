
package umontreal.iro.lecuyer.probdist;

/**
 * Extends the {@link ExponentialDist} class with a constructor accepting as
 * argument the mean <SPAN CLASS="MATH">1/<I>&#955;</I></SPAN> instead of the rate <SPAN CLASS="MATH"><I>&#955;</I></SPAN>.
 * 
 */
public class ExponentialDistFromMean extends ExponentialDist {



   /**
    * Constructs a new exponential distribution with mean <TT>mean</TT>.
    * 
    * @param mean the required mean.
    * 
    */
   public ExponentialDistFromMean (double mean) {
      super (1.0 / mean);
   }


   /**
    * Calls 
    * {@link umontreal.iro.lecuyer.probdist.ExponentialDist#setLambda(double) setLambda}
    *  with argument <TT>1/mean</TT> to change the mean of this distribution.
    * 
    * @param mean the new mean.
    * 
    */
   public void setMean (double mean) {
      setLambda (1.0 / mean);
   }
}
