
/* *
 * Title:        <p>
 * Description:  <p>
 * Copyright:    Copyright (c) <p>
 * Company:      <p>
 * @author
 * @version 1.0
 */

package umontreal.iro.lecuyer.probdist;

import umontreal.iro.lecuyer.probdist.BetaDist;
import umontreal.iro.lecuyer.util.*;

/**
 * Extends the class {@link ContinuousDistribution} for
 * the <SPAN  CLASS="textit">Fisher F</SPAN> distribution with <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN>
 * degrees of freedom, where <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN> are positive integers.
 * Its density is
 * <P>
 * </P>
 * <DIV ALIGN="CENTER" CLASS="mathdisplay">
 * <I>f</I> (<I>x</I>) = <I>&#915;</I>((<I>n</I> + <I>m</I>)/2)<I>n</I><SUP>n/2</SUP><I>m</I><SUP>m/2</SUP>/[<I>&#915;</I>(<I>n</I>/2)<I>&#915;</I>(<I>m</I>/2)]<I>x</I><SUP>(n-2)/2</SUP>/(<I>m</I> + <I>nx</I>)<SUP>(n+m)/2</SUP>,&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; for <I>x</I> &gt; 0.
 * </DIV><P></P>
 * where <SPAN CLASS="MATH"><I>&#915;</I>(<I>x</I>)</SPAN> is the gamma function defined in
 * {@link GammaDist}.
 * 
 */
public class FisherFDist extends ContinuousDistribution {
   protected int n;
   protected int m;
   protected double C1;



   /**
    * Constructs a Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution with <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN> degrees of freedom.
    * 
    */
   public FisherFDist (int n, int m) {
      setParams (n, m);
   }


   public double density (double x) {
      if (x <= 0.0)
         return 0.0;
      return Math.exp (C1 + 0.5 * (n - 2) * Math.log (x) -
           (0.5 * (n + m) * Math.log (m + n * x)));
   }

   public double cdf (double x) {
      return FisherFDist.cdf (n, m, decPrec, x);
   }

   public double barF (double x) {
      return FisherFDist.barF (n, m, decPrec, x);
   }

   public double inverseF (double u) {
      return FisherFDist.inverseF (n, m, decPrec, u);
   }

   public double getMean() {
      return FisherFDist.getMean (n, m);
   }

   public double getVariance() {
      return FisherFDist.getVariance (n, m);
   }

   public double getStandardDeviation() {
      return FisherFDist.getStandardDeviation (n, m);
   }

   /**
    * Computes the density function
    *   for a Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution with <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN> degrees of freedom.
    * 
    */
   public static double density (int n, int m, double x) {
      if (n <= 0)
         throw new IllegalArgumentException ("n <= 0");
      if (m <= 0)
         throw new IllegalArgumentException ("m <= 0");
      if (x <= 0.0)
         return 0.0;

      return Math.exp (((n / 2.0) * Math.log (n) + (m / 2.0) * Math.log (m) +
          ((n - 2) / 2.0) * Math.log (x)) -
           (Num.lnBeta (n / 2.0, m / 2.0) + ((n + m) / 2.0) * Math.log (m + n * x)));
   }


   /**
    * Computes the distribution function of the Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution with parameters
    *    <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN>, evaluated at <SPAN CLASS="MATH"><I>x</I></SPAN>, with roughly <SPAN CLASS="MATH"><I>d</I></SPAN> decimal digits of precision.
    * 
    */
   public static double cdf (int n, int m, int d, double x) {
      if (n <= 0)
         throw new IllegalArgumentException ("n <= 0");
      if (m <= 0)
         throw new IllegalArgumentException ("m <= 0");
      if (x <= 0.0)
         return 0.0;

      return BetaDist.cdf ((n / 2.0), (m / 2.0), d, ((n * x) / (n * x + m)));
   }


   /**
    * Computes the complementary distribution function of the Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution
    *    with parameters <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN>, evaluated at <SPAN CLASS="MATH"><I>x</I></SPAN>, with roughly <SPAN CLASS="MATH"><I>d</I></SPAN> decimal digits of precision.
    * 
    */
   public static double barF (int n, int m, int d, double x) {
      if (n <= 0)
         throw new IllegalArgumentException ("n <= 0");
      if (m <= 0)
         throw new IllegalArgumentException ("m <= 0");
      if (x <= 0.0)
         return 1.0;

      return BetaDist.barF ((n / 2.0), (m / 2.0), d, ((n * x) / (n * x + m)));
   }


   /**
    * Computes the inverse of the Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution
    *    with parameters <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN>, evaluated at <SPAN CLASS="MATH"><I>x</I></SPAN>, with roughly <SPAN CLASS="MATH"><I>d</I></SPAN>
    *    decimal digits of precision.
    * 
    */
   public static double inverseF (int n, int m, int d, double u) {
      double z;

      if (n <= 0)
         throw new IllegalArgumentException ("n <= 0");
      if (m <= 0)
         throw new IllegalArgumentException ("m <= 0");
      if (u > 1.0 || u < 0.0)
         throw new IllegalArgumentException ("u < 0 or u > 1");
      if (u <= 0.0)
         return 0.0;
      if (u >= 1.0)
         return Double.POSITIVE_INFINITY;

      z = BetaDist.inverseF ((n / 2.0), (m / 2.0), d, u);

      return ((m * z) / (n * (1 - z)));
   }


   /**
    * Computes and returns the mean 
    * <SPAN CLASS="MATH"><I>E</I>[<I>X</I>] = <I>m</I>/(<I>m</I> - 2)</SPAN> of the
    *    Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution with parameters <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN>.
    * 
    * @return the mean of the Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution
    * 
    */
   public static double getMean (int n, int m) {
      if (n <= 0)
         throw new IllegalArgumentException ("n <= 0");
      if (m <= 2)
         throw new IllegalArgumentException ("m <= 2");

      return (m / (m - 2.0));
   }


   /**
    * Computes and returns the variance
    * of the Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution with parameters <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN>.
    * 
    * @return the variance of the Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution
    *    
    * <SPAN CLASS="MATH">Var[<I>X</I>] = (2<I>m</I><SUP>2</SUP>(<I>m</I> + <I>n</I> - 2))/(<I>n</I>(<I>m</I> - 2)<SUP>2</SUP>(<I>m</I> - 4))</SPAN>
    * 
    */
   public static double getVariance (int n, int m) {
      if (n <= 0)
         throw new IllegalArgumentException ("n <= 0");
      if (m <= 4)
         throw new IllegalArgumentException ("m <= 4");

      return ((2.0 * m * m * (m + n - 2)) / (n * (m - 2.0) * (m - 2.0) * (m - 4.0)));
   }


   /**
    * Computes and returns the standard deviation
    *    of the Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution with parameters <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN>.
    * 
    * @return the standard deviation of the Fisher <SPAN CLASS="MATH"><I>F</I></SPAN> distribution
    * 
    */
   public static double getStandardDeviation (int n, int m) {
      return Math.sqrt (FisherFDist.getVariance (n, m));
   }


   /**
    * Returns the parameter <SPAN CLASS="MATH"><I>n</I></SPAN> of this object.
    * 
    */
   public int getN() {
      return n;
   }


   /**
    * Returns the parameter <SPAN CLASS="MATH"><I>m</I></SPAN> of this object.
    * 
    */
   public int getM() {
      return m;
   }


   /**
    * Sets the parameters <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>m</I></SPAN> of this object.
    * 
    */
   public void setParams (int n, int m) {
      if (n <= 0)
         throw new IllegalArgumentException ("n <= 0");
      if (m <= 0)
         throw new IllegalArgumentException ("m <= 0");

      this.n = n;
      this.m = m;
      supportA = 0;
      C1 = (n / 2.0) * Math.log (n) + (m / 2.0) * Math.log (m) -
           Num.lnBeta (n / 2.0, m / 2.0);
   }


   /**
    * Return a table containing the parameters of the current distribution.
    *    This table is put in regular order: [<SPAN CLASS="MATH"><I>n</I></SPAN>, <SPAN CLASS="MATH"><I>m</I></SPAN>].
    * 
    * 
    */
   public double[] getParams () {
      double[] retour = {n, m};
      return retour;
   }


   public String toString () {
      return getClass().getSimpleName() + " : n = " + n + ", m = " + m;
   }

}
