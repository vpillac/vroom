
package umontreal.iro.lecuyer.randvar;
import umontreal.iro.lecuyer.probdist.BernoulliDist;
import umontreal.iro.lecuyer.rng.RandomStream;

/**
 * This class implements random variate generators for the 
 * <EM>Bernoulli</EM> distribution (see class
 *  {@link umontreal.iro.lecuyer.probdist.BernoulliDist BernoulliDist}).
 * 
 */
public class BernoulliGen extends RandomVariateGenInt  {
   protected double p;    
    


   /**
    * Creates a Bernoulli random variate generator with parameter <SPAN CLASS="MATH"><I>p</I></SPAN>,
    *   using stream <TT>s</TT>.
    * 
    */
   public BernoulliGen (RandomStream s, double p) {
      super (s, new BernoulliDist (p));
      setParams (p);
   }


   /**
    * Creates a random variate generator for the <EM>Bernoulli</EM> 
    *     distribution <TT>dist</TT> and the random stream <TT>s</TT>.
    * 
    */
   public BernoulliGen (RandomStream s, BernoulliDist dist)  {
      super (s, dist);
      if (dist != null)
         setParams (dist.getP());
   }


   /**
    * Generates a new integer from the <EM>Bernoulli</EM> distribution with
    *   parameter <SPAN CLASS="MATH"><I>p</I> =</SPAN>&nbsp;<TT>p</TT>, using the given stream <TT>s</TT>.
    * 
    */
   public static int nextInt (RandomStream s, double p) {
      return BernoulliDist.inverseF (p, s.nextDouble());
   }


   /**
    * Returns the parameter <SPAN CLASS="MATH"><I>p</I></SPAN> of this object.
    * 
    * 
    */
   public double getP() {
      return p;
   }
   


   /**
    * Sets the parameter <SPAN CLASS="MATH"><I>p</I></SPAN> of this object.
    * 
    */
   protected void setParams (double p) {
      if (p < 0.0 || p > 1.0)
         throw new IllegalArgumentException ("p not in range [0, 1]");
      this.p = p;
   }

}
