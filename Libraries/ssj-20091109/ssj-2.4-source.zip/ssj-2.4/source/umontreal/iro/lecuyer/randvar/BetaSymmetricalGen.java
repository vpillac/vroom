
package umontreal.iro.lecuyer.randvar;
import umontreal.iro.lecuyer.rng.*;
import umontreal.iro.lecuyer.probdist.*;


/**
 * This class implements random variate generators with the <SPAN  CLASS="textit">symmetrical</SPAN>
 * <EM>beta</EM> distribution with shape parameters  
 * <SPAN CLASS="MATH"><I>&#945;</I> = <I>&#946;</I></SPAN>,
 * over the interval  <SPAN CLASS="MATH">(0, 1)</SPAN>. 
 * 
 */
public class BetaSymmetricalGen extends BetaGen  {



   /**
    * Creates a new symmetrical beta generator with parameters <SPAN CLASS="MATH"><I>&#945;</I> =</SPAN> 
    *   <TT>alpha</TT>, over the interval <SPAN CLASS="MATH">(0, 1)</SPAN>, using stream <TT>s</TT>.
    * 
    */
   public BetaSymmetricalGen (RandomStream s, double alpha)  {
      this (s, new BetaSymmetricalDist (alpha));
   }


   /**
    * Creates a new generator for the distribution <TT>dist</TT>,
    *      using stream <TT>s</TT>.
    * 
    */
   public BetaSymmetricalGen (RandomStream s, BetaSymmetricalDist dist)  {
      super (s, dist);
   }


   public static double nextDouble (RandomStream s, double alpha) {
      return BetaSymmetricalDist.inverseF (alpha, s.nextDouble());
   }

}
