
package umontreal.iro.lecuyer.randvar;
import umontreal.iro.lecuyer.probdist.*;
import umontreal.iro.lecuyer.rng.*;

/**
 * This class implements random variate generators for the 
 * <EM>binomial</EM> distribution. It has parameters <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>p</I></SPAN> with
 *  mass function
 * 
 * <P></P>
 * <DIV ALIGN="CENTER" CLASS="mathdisplay">
 * <I>p</I>(<I>x</I>) = nCr(<I>n</I>, <I>x</I>)<I>p</I><SUP>x</SUP>(1 - <I>p</I>)<SUP>n-x</SUP> = <I>n</I>!/(<I>x</I>!(<I>n</I> - <I>x</I>)!) &nbsp;<I>p</I><SUP>x</SUP>(1 - <I>p</I>)<SUP>n-x</SUP>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;for <I>x</I> = 0, 1, 2,..., <I>n</I>
 * </DIV><P></P>
 * where nCr<SPAN CLASS="MATH">(<I>n</I>, <I>x</I>)</SPAN> is the number of combinations of <SPAN CLASS="MATH"><I>x</I></SPAN> objects
 * among <SPAN CLASS="MATH"><I>n</I></SPAN>,
 * <SPAN CLASS="MATH"><I>n</I></SPAN> is a positive integer, and 
 * <SPAN CLASS="MATH">0&nbsp;&lt;=&nbsp;<I>p</I>&nbsp;&lt;=&nbsp;1</SPAN>.
 * 
 * <P>
 * The (non-static) <TT>nextInt</TT> method simply calls <TT>inverseF</TT> on the
 * distribution.
 * 
 */
public class BinomialGen extends RandomVariateGenInt  {
   protected int    n = -1;
   protected double p = -1.0;    
    


   /**
    * Creates a binomial random variate generator with parameters <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>p</I></SPAN>,
    *   using stream <TT>s</TT>.
    * 
    */
   public BinomialGen (RandomStream s, int n, double p) {
      super (s, new BinomialDist (n, p));
      setParams (n, p);
   }


   /**
    * Creates a random variate generator for the <EM>binomial</EM> 
    *     distribution <TT>dist</TT> and the random stream <TT>s</TT>.
    * 
    */
   public BinomialGen (RandomStream s, BinomialDist dist)  {
      super (s, dist);
      if (dist != null)
         setParams (dist.getN(), dist.getP());
   }


   /**
    * Generates a new integer from the <EM>binomial</EM> distribution with
    *   parameters
    *    <SPAN CLASS="MATH"><I>n</I> =</SPAN>&nbsp;<TT>n</TT> and <SPAN CLASS="MATH"><I>p</I> =</SPAN>&nbsp;<TT>p</TT>, using the given stream <TT>s</TT>.
    * 
    */
   public static int nextInt (RandomStream s, int n, double p) {
      return BinomialDist.inverseF (n, p, s.nextDouble());
   }


   /**
    * Returns the parameter <SPAN CLASS="MATH"><I>n</I></SPAN> of this object.
    * 
    */
   public int getN() {
      return n;
   }
   


   /**
    * Returns the parameter <SPAN CLASS="MATH"><I>p</I></SPAN> of this object.
    * 
    * 
    */
   public double getP() {
      return p;
   }
   


   /**
    * Sets the parameter <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>p</I></SPAN> of this object.
    * 
    */
   protected void setParams (int n, double p) {
      if (p < 0.0 || p > 1.0)
         throw new IllegalArgumentException ("p not in range [0, 1]");
      if (n <= 0)
         throw new IllegalArgumentException ("n <= 0");
      this.p = p;
      this.n = n;
   }

}
