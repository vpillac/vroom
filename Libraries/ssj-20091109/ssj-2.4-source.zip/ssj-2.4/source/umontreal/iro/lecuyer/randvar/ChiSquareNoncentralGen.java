
package umontreal.iro.lecuyer.randvar;
import umontreal.iro.lecuyer.rng.*;
import umontreal.iro.lecuyer.probdist.*;


/**
 * This class implements random variate generators for the
 * <EM>noncentral chi square</EM> distribution with <SPAN CLASS="MATH"><I>&#957;</I></SPAN> degrees of freedom
 * and noncentrality parameter <SPAN CLASS="MATH"><I>&#955;</I></SPAN>. See the definition in
 *  {@link umontreal.iro.lecuyer.probdist.ChiSquareNoncentralDist ChiSquareNoncentralDist}.
 * 
 */
public class ChiSquareNoncentralGen extends RandomVariateGen  {
   protected double nu = -1.0;
   protected double lambda = -1.0;




   /**
    * Creates a <SPAN  CLASS="textit">noncentral chi square</SPAN>  random variate generator
    *  with  <SPAN CLASS="MATH"><I>&#957;</I> &gt; 0</SPAN> degrees of freedom and noncentrality parameter <SPAN CLASS="MATH"><I>&#955;</I> &gt; 0</SPAN>,
    *  using stream <TT>s</TT>.
    * 
    */
   public ChiSquareNoncentralGen (RandomStream s, double nu, double lambda)  {
      super (s, new ChiSquareNoncentralDist(nu, lambda));
      setParams (nu, lambda);
   }


   /**
    * Create a new generator for the distribution <TT>dist</TT>
    *     and stream <TT>s</TT>.
    * 
    */
   public ChiSquareNoncentralGen (RandomStream s,
                                  ChiSquareNoncentralDist dist)  {
      super (s, dist);
      if (dist != null)
         setParams (dist.getNu (), dist.getLambda());
   }


   /**
    * Generates a new variate from the noncentral chi square
    * distribution with <SPAN CLASS="MATH"><I>&#957;</I></SPAN> degrees of freedom and noncentrality parameter <SPAN CLASS="MATH"><I>&#955;</I></SPAN>,
    *  using stream <TT>s</TT>.
    * 
    */
   public static double nextDouble (RandomStream s,
                                    double nu, double lambda)  {
      return ChiSquareNoncentralDist.inverseF (nu, lambda, s.nextDouble());
   }



   /**
    * Returns the value of  <SPAN CLASS="MATH"><I>&#957;</I></SPAN> of this object.
    * 
    */
   public double getNu() {
      return nu;
   }


   /**
    * Returns the value of <SPAN CLASS="MATH"><I>&#955;</I></SPAN> for this object.
    * 
    * 
    */
   public double getLambda() {
      return lambda;
   }


   /**
    * Sets the parameters <SPAN CLASS="MATH"><I>&#957;</I> =</SPAN> <TT>nu</TT> and <SPAN CLASS="MATH"><I>&#955;</I> =</SPAN>
    *   <TT>lambda</TT> of this object.
    * 
    */
   protected void setParams (double nu, double lambda) {
      if (nu <= 0.0)
         throw new IllegalArgumentException ("nu <= 0");
      if (lambda < 0.0)
         throw new IllegalArgumentException ("lambda < 0");
      this.nu = nu;
      this.lambda = lambda;
   }

}
