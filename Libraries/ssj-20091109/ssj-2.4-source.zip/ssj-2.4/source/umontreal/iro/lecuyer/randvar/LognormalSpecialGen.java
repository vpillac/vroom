
package umontreal.iro.lecuyer.randvar;

/**
 * Implements methods for generating random variates from the 
 * <EM>lognormal</EM> distribution using an arbitrary normal random 
 * variate generator.
 * The (non-static) <TT>nextDouble</TT> method calls the <TT>nextDouble</TT> 
 * method of the normal generator and takes the exponential of the result.
 * 
 */
public class LognormalSpecialGen extends RandomVariateGen  {

   NormalGen myGen;

   /**
    * Create a lognormal random variate generator 
    *    using the normal generator <TT>g</TT> and with the same parameters.
    * 
    */
   public LognormalSpecialGen (NormalGen g)  {
      // Necessary to compile, but we do not want to use stream and dist
      super (g.stream, null);
      stream = null;
      myGen = g;
   }
 

   public double nextDouble() {
      return Math.exp (myGen.nextDouble());
   }

}
