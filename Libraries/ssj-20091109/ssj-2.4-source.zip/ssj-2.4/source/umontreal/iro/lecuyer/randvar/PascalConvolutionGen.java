
package umontreal.iro.lecuyer.randvar;
import umontreal.iro.lecuyer.rng.*;
import umontreal.iro.lecuyer.probdist.*;


/**
 * Implements <SPAN  CLASS="textit">Pascal</SPAN> random variate generators by
 * the <SPAN  CLASS="textit">convolution</SPAN> method.
 * The method generates <SPAN CLASS="MATH"><I>n</I></SPAN> geometric variates with probability <SPAN CLASS="MATH"><I>p</I></SPAN>
 * and adds them up.
 * 
 * <P>
 * The algorithm is slow if <SPAN CLASS="MATH"><I>n</I></SPAN> is large.
 * 
 */
public class PascalConvolutionGen extends PascalGen  {



   /**
    * Creates a <SPAN  CLASS="textit">Pascal</SPAN> random variate generator with parameters
    *   <SPAN CLASS="MATH"><I>n</I></SPAN> and <SPAN CLASS="MATH"><I>p</I></SPAN>, using stream <TT>s</TT>.
    * 
    */
   public PascalConvolutionGen (RandomStream s, int n, double p) {
      super (s, null);
      setParams (n, p);
   }


   /**
    * Creates a new generator for the distribution <TT>dist</TT>, using
    *   stream <TT>s</TT>.
    * 
    */
   public PascalConvolutionGen (RandomStream s, PascalDist dist) {
      super (s, dist);
   }
 
    
   public int nextInt() {
      int x = 0;
      for (int i = 0; i < n; i++)
         x += GeometricDist.inverseF (p, stream.nextDouble());
      return x;

   }
    
   public static int nextInt (RandomStream s, int n, double p) {
     return convolution (s, n, p);
   }
   /**
    * Generates a new variate from the <SPAN  CLASS="textit">Pascal</SPAN> distribution,
    *   with parameters <SPAN CLASS="MATH"><I>n</I> =</SPAN>&nbsp;<TT>n</TT> and <SPAN CLASS="MATH"><I>p</I> =</SPAN>&nbsp;<TT>p</TT>, using the stream <TT>s</TT>.
    * 
    */


   private static int convolution (RandomStream stream, int n, double p) {
      int x = 0;
      for (int i = 0; i < n; i++)
         x += GeometricDist.inverseF (p, stream.nextDouble());
      return x;
   }
}
