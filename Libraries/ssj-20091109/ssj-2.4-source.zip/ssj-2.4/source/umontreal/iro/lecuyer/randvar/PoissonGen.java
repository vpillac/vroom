
package umontreal.iro.lecuyer.randvar;
import umontreal.iro.lecuyer.probdist.*;
import umontreal.iro.lecuyer.rng.*;
   
/**
 * This class implements random variate generators having the <EM>Poisson</EM> 
 * distribution.  Its mass function is
 * 
 * <P></P>
 * <DIV ALIGN="CENTER" CLASS="mathdisplay">
 * <I>p</I>(<I>x</I>) = <I>e</I><SUP>-<I>&#955;</I></SUP><I>&#955;</I><SUP>x</SUP>/(<I>x</I>!) for <I>x</I> = 0, 1,...
 * </DIV><P></P>
 * where 
 * <SPAN CLASS="MATH"><I>&#955;</I> &gt; 0</SPAN> is a real valued parameter equal to the mean.
 * 
 * <P>
 * No local copy of the parameter <SPAN CLASS="MATH"><I>&#955;</I> =</SPAN> <TT>lambda</TT>
 * is maintained in this class.
 * The (non-static) <TT>nextInt</TT> method simply calls <TT>inverseF</TT> on the
 * distribution.
 * 
 */
public class PoissonGen extends RandomVariateGenInt  {
   protected double lambda; 



   /**
    * Creates a Poisson random variate generator with 
    *   parameter <SPAN CLASS="MATH"><I>&#955;</I> =</SPAN> <TT>lambda</TT>, using stream <TT>s</TT>.
    * 
    */
   public PoissonGen (RandomStream s, double lambda)  {
      super (s, new PoissonDist (lambda));
      setParams (lambda);
   }


   /**
    * Creates a new random variate generator using the Poisson 
    *     distribution <TT>dist</TT> and stream <TT>s</TT>.
    * 
    */
   public PoissonGen (RandomStream s, PoissonDist dist)  {
      super (s, dist);
      if (dist != null)
         setParams (dist.getLambda());
   }


   /**
    * A static method for generating a random variate from a 
    *   <EM>Poisson</EM> distribution with parameter <SPAN CLASS="MATH"><I>&#955;</I></SPAN> = <TT>lambda</TT>.
    * 
    */
   public static int nextInt (RandomStream s, double lambda)  {
      return PoissonDist.inverseF (lambda, s.nextDouble());
   }


   /**
    * Returns the <SPAN CLASS="MATH"><I>&#955;</I></SPAN> associated with this object.
    * 
    * 
    */
   public double getLambda() {
      return lambda;
   }



   /**
    * Sets the parameter <SPAN CLASS="MATH"><I>&#955;</I> =</SPAN> <TT>lam</TT> of this object.
    * 
    */
   protected void setParams (double lam) {
      if (lam <= 0.0)
         throw new IllegalArgumentException ("lambda <= 0");
      this.lambda = lam;
   }

}