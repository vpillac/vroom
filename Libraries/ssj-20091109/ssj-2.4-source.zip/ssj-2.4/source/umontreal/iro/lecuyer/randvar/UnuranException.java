
package umontreal.iro.lecuyer.randvar;

/**
 * This type of unchecked exception is thrown when an error occurs
 * <SPAN  CLASS="textit">inside</SPAN> the UNURAN package.  
 * Usually, such an exception will come from the native side.
 * 
 */
public class UnuranException extends RuntimeException {

   /**
    * Constructs a new generic UNURAN exception.
    * 
    */
   public UnuranException() {
      super();
   }


   /**
    * Constructs a UNURAN exception with the error
    *    message <TT>message</TT>
    * 
    * @param message error message describing the problem that occurred
    * 
    */
   public UnuranException (String message) {
      super (message);
   }
}
