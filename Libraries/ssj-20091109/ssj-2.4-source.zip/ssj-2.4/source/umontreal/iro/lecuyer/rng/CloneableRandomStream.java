
package umontreal.iro.lecuyer.rng;

/**
 * {@link CloneableRandomStream} extends {@link RandomStream} and {@link Cloneable}. 
 * All classes that implements this interface are able to produce cloned objects.
 * 
 * <P>
 * The cloned object is entirely independent of the older odject.
 * Moreover the cloned object has all the same properties as the older one. 
 * All his seeds are duplicated, and therefore both generators will produce the
 * same random number sequence.
 * 
 */
public interface CloneableRandomStream extends RandomStream, Cloneable  { 


   /**
    * Clones the current object and returns its copy.
    *  
    *  @return A deep copy of the current object
    * 
    */
   public CloneableRandomStream clone();
 
}

