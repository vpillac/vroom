
package umontreal.iro.lecuyer.simprocs;

import umontreal.iro.lecuyer.simprocs.SimProcess;


/**
 * This class represents a record object to store 
 * information related to the request of a process for a
 * {@link Resource} or for {@link Bin} tokens, 
 * or when a process waits for a {@link Condition}.
 * A {@link UserRecord} is created for each process request.
 * The record contains the number of units requested 
 * or used, the associated process, and the
 * simulation time when the request was made.
 * Lists of processes waiting for a {@link Resource},
 * {@link Bin}, or {@link Condition}, for example, contain
 * {@link UserRecord} objects.
 * 
 */
public class UserRecord  {
   // Nb. of units taken for this record.
   protected int numUnits;

   // Process associated to the record
   protected SimProcess process;

   // Priority of this process.
   // protected double priority;

   // Time of the record creation
   protected double requestTime;

   // Constructor.
   // We do not want the user to construct such objects.
   protected UserRecord (int n, SimProcess p, double requestTime) {
      numUnits = n;
      process = p;
      this.requestTime = requestTime;
   }

   /**
    * Returns the number of units requested or used
    *    by the associated process.
    * 
    * @return the number of requested or used units
    * 
    */
   public int getNumUnits() {
      return numUnits;
   }


   /**
    * Returns the process object associated with this record.
    * 
    * @return the process associated to this record
    * 
    */
   public SimProcess getProcess() {
      return process;
   }


   /**
    * Returns the time of creation of this record.  
    * 
    * @return the simulation time of the record creation
    */
   public double getRequestTime() {
      return requestTime;
   }
}
