package vroom.common.modeling.dataModel.attributes;

/**
 * The Interface IVehicleAttribute.
 * 
 * @author Victor Pillac, <a href="http://uniandes.edu.co">Universidad de Los Andes</a> - <a
 *         href="http://copa.uniandes.edu.co">Copa</a>, <a href="http://www.emn.fr">Ecole des Mines de Nantes</a>-<a
 *         href="http://www.irccyn.ec-nantes.fr/irccyn/d/en/equipes/Slp">SLP</a>
 * @version 1.0 #created 24-Feb-2010 01:48:53 p.m.
 */
public interface IVehicleAttribute extends IAttribute {

}