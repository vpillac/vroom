/*
 * 
 */
package vroom.common.utilities.events;

/**
 * Exceptions raised when handling events
 */
public class EventHandlingException extends Exception {

    /**
	 * 
	 */
    private static final long serialVersionUID = 1L;
}